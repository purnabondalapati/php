export class Favorites extends $e.modules.CommandData {
	static getEndpointFormat() {
		return 'kits/favorites/{id}';
	}
}
