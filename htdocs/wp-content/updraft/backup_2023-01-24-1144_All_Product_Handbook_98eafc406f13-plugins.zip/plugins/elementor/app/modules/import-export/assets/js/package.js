// Alphabetical order.
import Layout from './templates/layout';
import Module from './module';

export default {
	Layout,
	Module,
};
